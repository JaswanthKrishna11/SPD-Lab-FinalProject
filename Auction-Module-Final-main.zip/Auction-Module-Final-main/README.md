﻿# Auction-Module-Final
 # Needs to be Deployed
 --Added Multiple Buttons for bidding <br />
 --Added Home button ( Only u want to route it ) <br />
     -- File Location (Components->Authentication->NavComp) <br />
     -- Css file will also be there in the same location<br />
